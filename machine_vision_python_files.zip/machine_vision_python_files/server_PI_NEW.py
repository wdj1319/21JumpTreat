#TCP/IP server setup
import socket
import threading
import numpy 
	
		#INITIALIZE
HEADER = 64 #first message to the server is always a header
PORT = 4050 #here is where we determine our port for our server, need to look further into what exactly we will need this to be. 
SERVER = "192.168.125.100" #ifconfig to find ip address to run on local network off this device or next line
#SERVER = socket.gethostbyname(socket.gethostname())
ADDR = (SERVER, PORT)
FORMAT = 'ascii' #a format for decoding our input strings
DISCONNECT_MESSAGE = "!DISCONNECT$"
OKAY_MESSAGE = "!OKAY$"
		
	
class serverPiNew:
	def __init__(self):
		"""
		
		
		"""
		
		str: self.msg = '' # 'self.' is equivalent to 'serverPiNew.'
		self.CONNECTION = 0
		int: self.ADDRESS = 0
	
	def serverInit(self):
		server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #IPV4 addresses, there are more types of inputs you can replace our AF_INET(soecifies the types of addresses we are looking to receive)
		server.bind(ADDR)
		print("[STARTING] server is starting...")
		print(f"[OUR ADDR] {ADDR} connected.")	
		server.listen()	
		self.start(server)
		'''print(f"[LISTENING] server is listening on {SERVER}")
		while True:
			try:
				CONNECTION, ADDRESS = server.accept()#waiting for connection, stores address(addr) of connection and object(conn) to allow us to communicate
			except socket.gaierror as e:
				print (f"Address-related error connecting to server: {e}")
				server.close()
			except socket.error as e:
				print(f"Connection error: {e}")
				server.close()	#SETUP LISTENING'''
	def storeInfo(self, msg: str) -> None:
		self.msg = msg
		
	def sendInfo(self):#handles individual connection between client and server; 1 client, 1 server
			#try:
		print(f"[NEW SEND]")
		multiplier = 2.268 #2.26842538
		xOffs = -964.044 #-964.0435248
		yOffs = -776.014 #-776.0142857
		sendStr = ''

			
		
		#while self.okay:
	#		msg_length = conn.recv(HEADER).decode(FORMAT)#begins our protocol setup; determines how many bytes to look for from client for initial message. This line is blocking, does not pass this line until this line is satisfied
	#		if msg_length:
	#			msg_length = int(msg_length)
		try:
			'''msg = "010 010"'''
			xyArray = self.msg.split(" ") #parsing string ({xdata} {ydata})
			xcamPos = float(xyArray[0]) 
			ycamPos = float(xyArray[1])
			xbotPos = float("{:.1f}".format(xcamPos * multiplier + xOffs)) #uses camera position with .format putting result to 1 decimal place, doing conversion from cam values to robot values 
			ybotPos = float("{:.1f}".format(ycamPos * multiplier + yOffs))
			'''if ybotPos >= 0.0:
			yPad = list(ybotPos) # all this code block was trying to compensate for string size when missing (negative sign) '-' found solution in robot studio parsing with strFind
			yPad.insert(0, '0')
			ybotStr = ''.join(yPad)
			if xbotPos >= 0.0:
			xPad = list(xbotPos)
			xPad.insert(0, '0')
			xbotStr = ''.join(xPad)'''
			
			sendStr = f"{xbotPos} {ybotPos};"#f"{xbotStr} {ybotStr}"#makes string out of float values of xpos and ypos
			message = sendStr.encode(FORMAT)#encodes string into byte-like object
			self.CONNECTION.send(message)
			self.msg = ''
		except socket.error as e:
			print (f"error sending data: {e}")
			self.CONNECTION.close()
		print(f"[MESSAGE SENT to {self.ADDRESS}] '{message}'")
			#self.okay = 0
	#		input()#want to click return to send info to the robot, having troubles sending/receiving strings :( 
			#'''try:
			#	msg = conn.recv(len("1234567890")).decode(FORMAT)#waiting to receive string
			#except socket.error as e:
			#	printf(f"Error receiving data: {e}")
			#	conn.close()
			
				
				
			#print(f"[{addr}] {msg}")
			

			#if msg ==DISCONNECT_MESSAGE:
			#	connected = False
			#connected = False
			#CONNECTION.close()#close current connection
			#except:'''
			
	def rcvInfo(self):#handles individual connection between client and server; 1 client, 1 server
			#try:
		print(f"[NEW CONNECTION] {self.ADDRESS} connected.")
			
		msgIn = ""
		self.okay = 0
			
		connected = True
		while connected:
	#		msg_length = conn.recv(HEADER).decode(FORMAT)#begins our protocol setup; determines how many bytes to look for from client for initial message. This line is blocking, does not pass this line until this line is satisfied
	#		if msg_length:
	#			msg_length = int(msg_length)
			'''try:
				#msg = "010 010"
				message = msg.encode(FORMAT)#encodes string into byte-like object
				CONNECTION.send(message)
			except socket.error as e:
				print (f"error sending data: {e}")
				CONNECTION.close()
	#		input()#want to click return to send info to the robot, having troubles sending/receiving strings :( 
			try:
				msg= conn.recv(len("1234567890")).decode(FORMAT)#waiting to receive string
			except socket.error as e:
				printf(f"Error receiving data: {e}")
				conn.close()'''
			print(f"[CONNECTION] {self.CONNECTION}")
#			while not msgIn.endswith('$'):
				#print(f"MSGIN HAPPENING {msgIn}")
				#msgIn += self.CONNECTION.recv(1).decode(FORMAT)
			msgIn = self.CONNECTION.recv(len(OKAY_MESSAGE)).decode(FORMAT)#waiting to receive string

			print(f"[{ADDR}] {msgIn}")
			
			if msgIn == OKAY_MESSAGE:
				self.okay = 1
				self.sendInfo()
				#thread._Thread_stop()
			else: 
				self.okay = 0
				print(f"[DID NOT GET !OKAY$]")

			if msgIn ==DISCONNECT_MESSAGE:
				connected = False
			return self.okay

			if connected == False:
				self.CONNECTION.close()#close current connection
				
			
	def start(self, server):#handles new connections, tells where to go

		print(f"[LISTENING] server is listening on {SERVER}")
		try:
			self.CONNECTION, self.ADDRESS = server.accept()#waiting for connection, stores address(addr) of connection and object(conn) to allow us to communicate
		except socket.gaierror as e:
			print (f"Address-related error connecting to server: {e}")
			server.close()
		except socket.error as e:
			print(f"Connection error: {e}")
			server.close()
	#		thread = threading.Thread(target=handle_client, args=(conn, addr))
	#		thread.start()
	#		print(f"[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")

	def send(self, msg):
		message = msg.encode(FORMAT)#encodes string into byte-like object
	#    msg_length = len(message)
	#   send_length = str(msg_length).encode(FORMAT)#first message we are going to send with info about length of message(which is the message we ultimately want to send)
	#   send_length += b' ' * (HEADER - len(send_length))#pads our initial string
	#server.send(send_length)
		try:
			server.send(message)
		except socket.error as e:
			print (f"error sending data: {e}")
			self.CONNECTION.close()


	#start()	

