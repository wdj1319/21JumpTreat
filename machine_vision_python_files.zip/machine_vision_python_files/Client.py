#TCP/IP client setup

    import socket
	
    #INITIALIZE
	HEADER = 64 #first message to the server is always a header
	PORT = 4491 #here is where we determine our port for our server, need to look further into what exactly we will need this to be. 
	#SERVER = "(ipaddress)" #ifconfig to find ip address to run on local network off this device or next line
	SERVER = socket.gethostbyname(socket.gethostname())
	ADDR = (SERVER, PORT)
	FORMAT = 'utf-8' #a format for decoding our input strings
	DISCONNECT_MESSAGE = "!DISCONNECT"
    
	
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect(ADDR)
    
    def send(msg):
        message = msg.encode(FORMAT)#encodes string into byte-like object
        msg_length = len(message)
        send_length = str(msg_length).encode(FORMAT)#first message we are going to send with info about length of message(which is the message we ultimately want to send)
        send_length += b' ' * (HEADER - len(send_length))#pads our initial string
        client.send(send_length)
        client.send(message)
        
    send("Hello World!")
    send("more messages")
    
    send(DISCONNECT_MESSAGE)#at this point we should have disconnected and we must rerun code to reconnect
        
