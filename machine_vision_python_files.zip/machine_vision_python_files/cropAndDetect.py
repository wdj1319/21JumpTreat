from roboflowoak import RoboflowOak
import cv2
import time
import numpy as np

def crop_frame(frame, x1, y1, x2, y2):
    cropped_frame = frame[y1:y2, x1:x2]
    return cropped_frame

if __name__ == '__main__':
    # Instantiating an object (rf) with the RoboflowOak module
    rf = RoboflowOak(
        model="21jumptreat",
        confidence=0.05,
        overlap=0.5,
        version="8",
        api_key="Kg00YrhjNERKxCQQo8En",
        rgb=True,
        depth=False,
        device=None,
        blocking=True
    )
    
    while True:
        t0 = time.time()
        result, frame, raw_frame, depth = rf.detect()    
        predictions = result["predictions"]
        
        # Calculate frames per second
        t = time.time() - t0
        fps = 1 / t

        # Print FPS and predictions
        print(f"FPS: {fps:.2f}")
        print("Predictions:")
        for i, prediction in enumerate(predictions):
            print(f"  Prediction {i+1}:")
            print(f"    Class: {prediction.class_name}")
            print(f"    Confidence: {prediction.confidence:.2f}")
            print(f"    Bounding Box: (x={prediction.x:.2f}, y={prediction.y:.2f}, width={prediction.width:.2f}, height={prediction.height:.2f})")

        # Crop the frame
        x1, y1, x2, y2 = 150, 275, 600, 550  # Example cropping region
        cropped_frame = crop_frame(frame, x1, y1, x2, y2)
        
        # Display the cropped frame
        cv2.imshow("frame", cropped_frame)
    
        # Close the OAK inference window / stop inference by pressing 'q'
        if cv2.waitKey(1) == ord('q'):
            break
