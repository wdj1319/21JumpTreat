from roboflowoak import RoboflowOak
from server_PI_NEW import serverPiNew
import threading
import cv2
import time

def crop_frame(frame, x1, y1, x2, y2):
    cropped_frame = frame[y1:y2, x1:x2]
    return cropped_frame

def filter_predictions(predictions, x1, y1, x2, y2):
    filtered_predictions = []
    for prediction in predictions:
        abs_center_x = int(prediction.x + prediction.width / 2)
        abs_center_y = int(prediction.y + prediction.height / 2)
        # Check if the center of the bounding box falls within the cropping region
        if x1 <= abs_center_x <= x2 and y1 <= abs_center_y <= y2:
            filtered_predictions.append(prediction)
    return filtered_predictions
    
def runLoop(pi): #def runLoop():
    x1, y1, x2, y2 = 150, 275, 600, 550  # Cropping region
    smallestX = 1000
    smallestY = 1000
    largestX = 0
    largestY = 0
    my_thread = start_threat()

    while True:
        t0 = time.time()
        result, frame, raw_frame, depth = rf.detect()
        predictions = result["predictions"] #PREDICTIONS STRUCTURE FROM RF.DETECT

        
        # Filter predictions based on whether the center falls within the cropping region
        filtered_predictions = filter_predictions(predictions, x1, y1, x2, 450)
        
        # Crop the frame
        cropped_frame = crop_frame(frame, x1, y1, x2, y2)
        
        # Display the cropped frame
        cv2.imshow("frame", cropped_frame)
        
        # Draw bounding boxes on the cropped frame for filtered predictions
        if filtered_predictions:
            first_prediction = filtered_predictions[0]
            abs_x1 = int(first_prediction.x * cropped_frame.shape[1])
            abs_y1 = int(first_prediction.y * cropped_frame.shape[0])
            abs_x2 = int(abs_x1 + first_prediction.width * cropped_frame.shape[1])
            abs_y2 = int(abs_y1 + first_prediction.height * cropped_frame.shape[0])
            cv2.rectangle(cropped_frame, (abs_x1, abs_y1), (abs_x2, abs_y2), (0, 255, 0), 2)
            #Print information only for predictions within the cropping region
             
            #--------------------------------------------------------------------------------------------------------#
            treat_info = f"{first_prediction.x} {first_prediction.y}" #TREAT STRING TO SEND TO ROBOT
            pi.storeInfo(treat_info)
            #--------------------------------------------------------------------------------------------------------#
            '''if first_prediction.x > largestX:       #checks if current X is larger than the largest detected X so far
                largestX = first_prediction.x       #if current X is larger than largest X yet, give largestX that value
            if first_prediction.y > largestY:       #same for largest Y
                largestY = first_prediction.y
            if first_prediction.x < smallestX:       #same for smallest X, but obviously looking for the smallest value
                smallestX = first_prediction.x
            if first_prediction.y < smallestY:       #same for smallest Y
                smallestY = first_prediction.y'''
            #--------------------------------------------------------------------------------------------------------#
            print(f"treat info: {treat_info}")
            '''print(f"Smallest X: {smallestX}, Y: {smallestY}, Largest X: {largestX}, Y: {largestY}")''' #this was just here to try and find camera max and mins

#        thread = threading.Thread(target=pi.rcvInfo, args=())
#    if not thread.is_alive():
#            thread.start()
            if not my_thread.is_alive():
                my_thread = start_threat() # re- starts thread

                #thread.start()            #then close from within thread when done function using 
        '''if okay == 1:
                pi.sendInfo(treat_info)#put in IF statement with global variable set by receiving our"OK!$" message
                okay = 0'''
        '''for prediction in filtered_predictions:
            abs_x1 = int(prediction.x * cropped_frame.shape[1])
            abs_y1 = int(prediction.y * cropped_frame.shape[0])
            abs_x2 = int(abs_x1 + prediction.width * cropped_frame.shape[1])
            abs_y2 = int(abs_y1 + prediction.height * cropped_frame.shape[0])
            cv2.rectangle(cropped_frame, (abs_x1, abs_y1), (abs_x2, abs_y2), (0, 255, 0), 2)
            # Print information only for predictions within the cropping region
            #print(f"Class: {prediction.class_name}, Confidence: {prediction.confidence:.2f}, Bounding Box: (x={prediction.x:.2f}, y={prediction.y:.2f}, width={prediction.width:.2f}, height={prediction.height:.2f})")'''
           
            

        # Calculate frames per second
        t = time.time() - t0
        fps = 1 / t

        # Print FPS
        print(f"FPS: {fps:.2f}")

        # Close the OAK inference window / stop inference by pressing 'q'
        if cv2.waitKey(1) == ord('q'):
            break
        #thread.close()
def start_threat():
    
    thread = threading.Thread(target=pi.rcvInfo, args=())
    thread.start()
    return thread
    
    
if __name__ == '__main__':
    rf = RoboflowOak(
        model="21jumptreat",
        confidence=0.05,
        overlap=0.5,
        version="8",
        api_key="Kg00YrhjNERKxCQQo8En",
        rgb=True,
        depth=False,
        device=None,
        blocking=True
    )
    pi = serverPiNew()
    pi.serverInit()
    runLoop(pi) #runLoop()
    cv2.destroyAllWindows()
