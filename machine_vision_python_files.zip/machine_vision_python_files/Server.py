#TCP/IP server setup
	import socket
	import threading
	
	
	#INITIALIZE
	HEADER = 64 #first message to the server is always a header
	PORT = 4491 #here is where we determine our port for our server, need to look further into what exactly we will need this to be. 
	#SERVER = "(ipaddress)" #ifconfig to find ip address to run on local network off this device or next line
	SERVER = socket.gethostbyname(socket.gethostname())
	ADDR = (SERVER, PORT)
	FORMAT = 'utf-8' #a format for decoding our input strings
	DISCONNECT_MESSAGE = "!DISCONNECT"
	
	server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) #IPV4 addresses, there are more types of inputs you can replace our AF_INET(soecifies the types of addresses we are looking to receive)
	server.bind(ADDR)
	
	#SETUP LISTENING
	def handle_client(conn, addr):#handles individual connection between client and server; 1 client, 1 server
		#try:
		print(f"[NEW CONNECTION] {addr} connected.")
		
		connected = True
		while connected:
			msg_length = conn.recv(HEADER).decode(FORMAT)#begins our protocol setup; determines how many bytes to look for from client for initial message. This line is blocking, does not pass this line until this line is satisfied
			if msg_length:
				msg_length = int(msg_length)
				msg = conn.recv(msg_length).decode(FORMAT)
				if msg ==DISCONNECT_MESSAGE:
					connected = False
			
				print(f"[{addr}] {msg}")
		conn.close()#close current connection
		#except:
			
		
	def start():#handles new connections, tells where to go
		server.listen()
		print(f"[LISTENING] server is listening on {SERVER}")
		while True:
			conn, addr = server.accept()#waiting for connection, stores address(addr) of connection and object(conn) to allow us to communicate
			thread = threading.Thread(target=handle_client, args=(conn, addr))
			thread.start()
			print(f"[ACTIVE CONNECTIONS] {threading.activeCount() - 1}")
			
			
			
	print("[STARTING] server is starting...")
	start()	
