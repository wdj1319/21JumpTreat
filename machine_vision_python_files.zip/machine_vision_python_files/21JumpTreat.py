from roboflowoak import RoboflowOak
import cv2
import time
import numpy as np

if __name__ == '__main__':
    # Instantiating an object (rf) with the RoboflowOak module
    rf = RoboflowOak(
        model="21jumptreat",
        confidence=0.05,
        overlap=0.5,
        version="2",
        api_key="Kg00YrhjNERKxCQQo8En",
        rgb=True,
        depth=False,
        device=None,
        blocking=True
    )
    
    while True:
        t0 = time.time()
        result, frame, raw_frame, depth = rf.detect()    
        predictions = result["predictions"]
        
        # Timing: for benchmarking purposes
        t = time.time() - t0
        print("FPS ", 1 / t)
        print(f"PREDICTIONS {predictions}", [p.json() for p in predictions])
        
        # Setting parameters for depth calculation
        # Comment out the following 2 lines if you're using an OAK without Depth
        # max_depth = np.amax(depth)
        # cv2.imshow("depth", depth / max_depth)
        
        # Displaying the video feed as successive frames
        cv2.imshow("frame", frame)
    
        # How to close the OAK inference window / stop inference: CTRL+q or CTRL+c
        if cv2.waitKey(1) == ord('q'):
            break
